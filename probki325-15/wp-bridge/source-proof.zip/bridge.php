<?php
/** Local demonstration only. JSON stdin -> native WordPress API, isolated DB copy. */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }
$base=__DIR__;
$config=json_decode(file_get_contents($base.'/private/runtime-config.json'),true,512,JSON_THROW_ON_ERROR);
define('ABSPATH',rtrim($config['wordpress_core'],'/').'/');
define('DB_NAME','workshop'); define('DB_USER','unused'); define('DB_PASSWORD','unused'); define('DB_HOST','localhost');
define('DB_CHARSET','utf8mb4'); define('DB_COLLATE',''); define('DB_ENGINE','sqlite');
define('DB_PATH',$base.'/private/wordpress.sqlite');
define('WP_CONTENT_DIR',$base.'/wp-content'); define('WP_CONTENT_URL','http://127.0.0.1:8785/wp-content');
define('WP_PLUGIN_DIR',WP_CONTENT_DIR.'/plugins'); define('WP_PLUGIN_URL',WP_CONTENT_URL.'/plugins');
define('WP_HOME','http://127.0.0.1:8785'); define('WP_SITEURL','http://127.0.0.1:8785');
define('WP_ENVIRONMENT_TYPE','local'); define('WP_HTTP_BLOCK_EXTERNAL',true); define('AUTOMATIC_UPDATER_DISABLED',true);
define('DISABLE_WP_CRON',true); define('DISALLOW_FILE_EDIT',true); define('DISALLOW_FILE_MODS',true);
define('WP_DEBUG',false); define('WP_DEBUG_DISPLAY',false); define('WP_TEMP_DIR',$base.'/private/tmp');
$table_prefix='workshop_';
$_SERVER['HTTP_HOST']='127.0.0.1:8785'; $_SERVER['REQUEST_URI']='/'; $_SERVER['SERVER_PROTOCOL']='HTTP/1.1';
require ABSPATH.'wp-settings.php';
add_filter('pre_wp_mail',static fn()=>false);
add_filter('pre_http_request',static fn()=>new WP_Error('local_demo_network_blocked','Network disabled in this local demonstration.'));
wp_set_current_user(1);
$request=json_decode(stream_get_contents(STDIN),true,512,JSON_THROW_ON_ERROR);
$id=(int)($request['page_id']??0);
if($id!==25)throw new RuntimeException('This demo permits only the known fictional sample page25.');
$post=get_post($id);
if(!$post||$post->post_type!=='page')throw new RuntimeException('Known sample page missing');
$op=$request['op']??'inspect';
$before=hash('sha256',$post->post_content);
$changes=[];
if($op==='apply') {
    $blocks=parse_blocks($post->post_content);
    $headingDone=false; $introDone=false;
    $walk=function(&$items)use(&$walk,&$headingDone,&$introDone,&$changes,$request) {
        foreach($items as &$b) {
            if(!$headingDone&&$b['blockName']==='core/heading'&&($b['attrs']['level']??2)===1) {
                $new='<h1 class="wp-block-heading">'.esc_html($request['hero_heading']).'</h1>';
                $b['innerHTML']=$new;$b['innerContent']=[$new];$headingDone=true;$changes[]='existing_core_heading';
            } elseif($headingDone&&!$introDone&&$b['blockName']==='core/paragraph') {
                $new='<p>'.esc_html($request['intro_copy']).'</p>';
                $b['innerHTML']=$new;$b['innerContent']=[$new];$introDone=true;$changes[]='existing_core_paragraph';
            }
            if(!empty($b['innerBlocks']))$walk($b['innerBlocks']);
        }
    };
    $walk($blocks);
    if(!$headingDone||!$introDone)throw new RuntimeException('Expected native heading and paragraph were not found');
    $cta='<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="'.esc_url($request['cta_url']).'">'.esc_html($request['cta_text']).'</a></div><!-- /wp:button --></div><!-- /wp:buttons -->';
    $blocks=array_merge($blocks,parse_blocks($cta));$changes[]='new_native_core_button';
    $new=serialize_blocks($blocks);
    $result=wp_update_post(['ID'=>$id,'post_content'=>wp_slash($new)],true);
    if(is_wp_error($result))throw new RuntimeException($result->get_error_message());
    clean_post_cache($id);$post=get_post($id);
} elseif($op!=='inspect') { throw new RuntimeException('Unsupported local operation'); }
$types=[];
$inspect=function($items)use(&$inspect,&$types){foreach($items as $b){if($b['blockName'])$types[]=$b['blockName'];if($b['innerBlocks'])$inspect($b['innerBlocks']);}};
$inspect(parse_blocks($post->post_content));
$rendered=apply_filters('the_content',$post->post_content);
echo json_encode(['checked_at'=>gmdate('c'),'operation'=>$op,'wordpress'=>get_bloginfo('version'),
 'page_id'=>$id,'page_type'=>$post->post_type,'native_api'=>['get_post','parse_blocks','serialize_blocks','wp_update_post'],
 'content_sha256'=>hash('sha256',$post->post_content),'before_sha256'=>$before,'native_block_types'=>$types,
 'changes'=>$changes,'expected_heading_present'=>str_contains($rendered,'Bridge: fikcyjna oferta demonstracyjna'),
 'expected_intro_present'=>str_contains($rendered,'Zmiana treści przez lokalny most JSON'),
 'expected_cta_present'=>str_contains($rendered,'Sprawdź demonstrację'),
 'fiction_notice_preserved'=>str_contains($rendered,'wszystkie parametry są fikcyjne'),
 'email_allowed'=>false,'remote_http_allowed'=>false,'paid_client_case'=>false,
 'mcp_server_used'=>false,'wp_cli_used'=>false,'acf_pro_used'=>false,
 'rendered_html_sha256'=>hash('sha256',$rendered)],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),"\n";
