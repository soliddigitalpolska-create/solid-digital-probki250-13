"""Copy only demo DB; create isolated content root; test PHP JSON bridge, then restore.
No account cookies, browser state, production WordPress or client credentials used.
"""
from pathlib import Path
import hashlib,json,shutil,sqlite3,subprocess
from datetime import datetime,timezone

HERE=Path(__file__).resolve().parent
WORK=HERE.parents[1]
SOURCE=WORK/'useme-pakiet40-2026-10-11'/'native-wordpress-workshop'
PRIVATE=HERE/'private';PRIVATE.mkdir(exist_ok=True)
(PRIVATE/'tmp').mkdir(exist_ok=True)
CONTENT=HERE/'wp-content';CONTENT.mkdir(exist_ok=True)
(CONTENT/'uploads').mkdir(exist_ok=True)
source_db=SOURCE/'private'/'wordpress.sqlite'
target_db=PRIVATE/'wordpress.sqlite'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original_sha=sha(source_db)
with sqlite3.connect(source_db.as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(target_db) as dst:src.backup(dst)
shutil.copyfile(target_db,PRIVATE/'before.sqlite')
shutil.copyfile(SOURCE/'site/wordpress/wp-content/db.php',CONTENT/'db.php')
(PRIVATE/'runtime-config.json').write_text(json.dumps({'wordpress_core':(SOURCE/'site/wordpress').as_posix()}),encoding='utf-8')
for name in ['plugins','themes','mu-plugins']:
    target=CONTENT/name
    if not target.exists():
        # Native PowerShell junction creation; no move or deletion of source paths.
        origin=SOURCE/'site/wordpress/wp-content'/name
        command="New-Item -ItemType Junction -Path '"+str(target).replace("'","''")+"' -Target '"+str(origin).replace("'","''")+"' | Out-Null"
        subprocess.run(['powershell','-NoProfile','-Command',command],check=True,capture_output=True)

php=SOURCE/'runtime/php/php.exe'
def call(body):
    p=subprocess.run([str(php),'-c',str(SOURCE/'runtime/php/php.ini'),'-d','error_log='+str(PRIVATE/'php-error.log'),str(HERE/'bridge.php')],
        input=json.dumps(body,ensure_ascii=False),text=True,encoding='utf-8',capture_output=True,timeout=90)
    if p.returncode:raise RuntimeError('Local bridge failed: '+p.stderr[-1500:]+' '+p.stdout[-1500:])
    start=p.stdout.find('{')
    result=json.loads(p.stdout[start:])
    return result
before=call({'op':'inspect','page_id':25})
after=call({'op':'apply','page_id':25,'hero_heading':'Bridge: fikcyjna oferta demonstracyjna',
            'intro_copy':'Zmiana treści przez lokalny most JSON. To własny, fikcyjny przykład, a nie realizacja dla klienta.',
            'cta_text':'Sprawdź demonstrację','cta_url':'https://example.com/own-demo'})
readback=call({'op':'inspect','page_id':25})
assert after['content_sha256']==readback['content_sha256']!=before['content_sha256']
assert len(after['changes'])==3
assert all(readback[k] for k in ['expected_heading_present','expected_intro_present','expected_cta_present','fiction_notice_preserved'])
assert 'core/button' in readback['native_block_types'] and 'core/heading' in readback['native_block_types']
# All bridge processes have exited; restore only the isolated demonstration DB.
shutil.copyfile(PRIVATE/'before.sqlite',target_db)
restored=call({'op':'inspect','page_id':25})
assert restored['content_sha256']==before['content_sha256']
assert sha(source_db)==original_sha,'Original database changed unexpectedly'
evidence=dict(status='PASS_NATIVE_WORDPRESS_CLI_JSON_BRIDGE',checked_at=datetime.now(timezone.utc).isoformat(),
    actual_tools=['Codex agent','PowerShell process execution','PHP CLI','native WordPress API','SQLite isolated copy'],
    mcp_server_used=False,wp_cli_used=False,acf_pro_used=False,commercial_client_cases=0,
    scope='Three actual changes and readback in one self-made WordPress demonstration page, isolated database copy.',
    changes=after['changes'],new_heading_verified=readback['expected_heading_present'],
    intro_verified=readback['expected_intro_present'],native_cta_verified=readback['expected_cta_present'],
    native_block_types=readback['native_block_types'],before_sha256=before['content_sha256'],after_sha256=after['content_sha256'],
    persisted_fresh_process_readback=True,restore_verified=restored['content_sha256']==before['content_sha256'],
    original_database_unchanged=True,original_database_sha256=original_sha,
    network_enabled=False,mail_enabled=False,browser_visual_QA=False,
    source_files={'bridge.php':sha(HERE/'bridge.php'),'prepare-and-verify.py':sha(Path(__file__))},
    caveat='This is a local CLI JSON bridge proof, not a production MCP integration, ACF Pro case, or three separate client websites.')
(HERE/'native-bridge-proof.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name,value in [('before',before),('after',after),('readback',readback),('restored',restored)]:
    (HERE/(name+'-proof.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(evidence,ensure_ascii=False))
