WŁASNA PRÓBKA TECHNICZNA: CODEX -> CLI JSON -> NATYWNY WORDPRESS

To demonstracja techniczna na odizolowanej kopii bazy własnego projektu WordPress.
Nie jest realizacją komercyjną, integracją produkcyjną ani serwerem MCP.
Nie użyto WP-CLI ani ACF Pro; te narzędzia nie są deklarowane jako sprawdzone.

Trzy rzeczywiście wykonane zmiany:
1. Podmiana istniejącego nagłówka w natywnym bloku Gutenberg core/heading.
2. Aktualizacja akapitu w istniejącej grupie, z zachowaniem otaczających bloków.
3. Dodanie edytowalnego przycisku core/button w kontenerze core/buttons.

Kod JSON -> PHP CLI -> parse_blocks/serialize_blocks/wp_update_post -> WordPress.
Zapis odczytano ponownie w nowym procesie. Sprawdzono renderowany nagłówek,
tekst i przycisk, natywne typy bloków oraz pozostawienie informacji o fikcyjnym demo.
Potem odtworzono kopię bazy i porównano hash treści. Oryginalna baza nie zmieniła się.

native-bridge-proof.json zawiera wynik i hashe źródeł. before/after/readback/restored
pokazują kolejne odczyty. bridge.php to faktycznie wykonane źródło mostu CLI.
prepare-and-verify.py przygotowuje kopię istniejącego lokalnego warsztatu i wykonuje test.

Próbka wymaga wcześniej uruchomionego lokalnego projektu WordPress/PHP/SQLite.
Kod nie jest gotowym modułem do umieszczenia na produkcji: obsługuje wyłącznie CLI
i jedną dozwoloną fikcyjną stronę. Do klienta trzeba dopasować autoryzację,
uprawnienia, selektory istniejących komponentów, schematy ACF i procedurę akceptacji.

Nie testowano w tej próbce ACF Pro ani zgodności z nieznanym motywem klienta.
Nie wykonano wizualnego QA przeglądarki dla zmienionej kopii; wykonano kontrolę
natywnego zapisu, parsowania bloków i wygenerowanego HTML. Nie uruchomiono poczty
ani zewnętrznych połączeń. Żaden plik prywatnej bazy lub danych logowania nie
wchodzi w skład tego pakietu.
