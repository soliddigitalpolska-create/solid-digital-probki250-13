# Brief Veyrelo

**Status: KOMPLETNY OPIS (100%)**
Kompletność oznacza opisanie zakresu. Nie jest akceptacją zlecenia ani potwierdzeniem dostarczenia materiałów.

## DEMO FIKCYJNE — kontrola CSV przed importem
Scenariusz: Ceny i cenniki

## Cel i problem
Na pięciu fikcyjnych produktach wykryć niejednoznaczną cenę, brak nazwy i ceny, powtórzony SKU oraz niepoprawny adres URL\. Oddzielić kosmetyczny trim od korekt wymagających jawnego źródła danych\.

## Proces: wejście → działanie → wynik
01\_wejscie\-z\-bledami\.csv → lokalny audyt CSV → 02\_raport\-przed\.json \(6 problemów, 4 rekordy\) → 03\_po\-samym\-trim\.csv \(2 zmiany, nadal 6 problemów\) → porównanie z fikcyjnym katalogiem 04 → 05\_po\-korektach\-ze\-zrodla\.csv → 06\_raport\-po\.json\. Pozycja\_demo wiąże ten sam produkt w obu tabelach\. Przy prawdziwym zleceniu źródło i każda zmiana wymagają uzgodnienia z klientem\.

## Kryteria odbioru
1. Problemy wykryte w pliku wejściowym: = 6 wpisów raportu
   Sprawdzenie: Zaimportuj 01 do publicznego audytora; separator średnik, mapowanie według nazw\. Wynik: 5 produktów, 6 problemów w 4 rekordach\.
2. Problemy po korektach ze źródła: = 0 wpisów raportu
   Sprawdzenie: Zaimportuj 05 do audytora z tym samym mapowaniem\. Brak problemów oznacza tylko przejście tych konkretnych kontroli\.
3. Korekty biznesowe mające jawne źródło: = 5 zmienionych komórek
   Sprawdzenie: Porównaj 03 i 05, korzystając z Pozycja\_demo\. Każda zmiana ma odpowiadać tabeli 04 oraz plikowi ZMIANY\_ZE\_ZRODLA\.json\.
4. Nowo dopisane identyfikatory GTIN: = 0 kodów
   Sprawdzenie: Kolumna GTIN pozostaje pusta we wszystkich 5 wierszach\. Braku GTIN nie wolno maskować wygenerowanym numerem\.

## Zależności
Materiał demonstracyjny zawiera fikcyjny katalog źródłowy\. Dla rzeczywistego projektu potrzebne będą reguły sklepu, właściwa specyfikacja importu oraz właściciel akceptujący dane\. Samego raportu audytora nie traktujemy jako autoryzacji importu\.

## Ograniczenia
CSV UTF\-8, separator średnik, ceny w PLN bez symbolu waluty i z przecinkiem dziesiętnym\. Wszystkie nazwy, SKU, kwoty i adresy są fikcyjne\. Adresy example\.invalid są celowo niedziałającymi przykładami\. Audyt sprawdza składnię URL, nie pobiera adresów\. GTIN w tym ćwiczeniu pozostaje nieustalony\. W prawdziwym katalogu wymagania identyfikatorów trzeba ustalić osobno\.

## Poza zakresem
Import do sklepu, połączenie z Merchant Center, wysyłka wiadomości lub ofert, płatności, dane prawdziwych klientów, certyfikacja i gwarancja przyjęcia pliku przez platformę\. Pakiet nie jest umową ani wyceną\.

## Materiały do rozpoczęcia
- Przykładowy cennik bez danych osobowych: **Gotowe** — 01\_wejscie\-z\-bledami\.csv; pięć fikcyjnych produktów, bez danych osobowych\.
- Reguły cen, walut i zaokrągleń: **Gotowe** — Reguły i jawna fikcyjna tabela 04 opisane w INSTRUKCJA\.md; każda cena pochodzi z tabeli 04\.
- Wzór oczekiwanego pliku wynikowego: **Gotowe** — 05\_po\-korektach\-ze\-zrodla\.csv oraz raport 06 pokazują oczekiwany wynik ćwiczenia\.
- Opis procesu akceptacji zmian: **Do dostarczenia** — Przed prawdziwym wdrożeniem klient musi wskazać właściciela danych i zatwierdzić reguły\. Nie ma tu rzeczywistej zgody klienta\.

Gotowość materiałów: 1 do dostarczenia lub ustalenia.

## Opcjonalne ograniczenia
Budżet: Nie podano
Termin: Nie podano

## Braki
Brak brakujących sekcji.

Plik utworzony lokalnie w narzędziu Veyrelo. Formularz nie wysyła danych.
