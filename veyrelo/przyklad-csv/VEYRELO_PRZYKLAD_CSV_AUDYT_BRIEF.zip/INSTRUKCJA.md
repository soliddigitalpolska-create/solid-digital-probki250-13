# Veyrelo: od błędnego CSV do briefu

To krótkie ćwiczenie na **5 fikcyjnych produktach**. Nie jest realizacją zlecenia, certyfikatem, wyceną ani historią prawdziwego klienta. Wszystkie nazwy, SKU, kwoty i adresy są demonstracyjne. Kolumna GTIN pozostaje pusta — nie generujemy identyfikatorów produktów.

## 1. Zobacz problem

Otwórz [audytor CSV](https://soliddigitalpolska-create.github.io/solid-digital-probki250-13/veyrelo/csv/) i wczytaj `01_wejscie-z-bledami.csv`.

Wybierz średnik oraz mapowanie SKU → SKU, Nazwa → Nazwa, Cena → Cena, GTIN → GTIN, URL → URL. `Pozycja_demo` jest pomocniczym identyfikatorem wiążącym produkt z tabelą źródłową; nie jest mapowanym SKU.

Oczekiwany wynik: **5 produktów, 6 problemów w 4 rekordach**. Numeracja raportu obejmuje nagłówek jako rekord 1, więc pierwszy produkt to rekord 2.

| Rekord raportu | Pozycja_demo | Problem |
|---|---:|---|
| 2 | 1 | SKU KUB-01 powtarza się po przycięciu brzegów |
| 3 | 2 | Powtórzony SKU |
| 3 | 2 | Cena `1,234` jest niejednoznaczna |
| 3 | 2 | `brak-adresu` nie jest pełnym adresem HTTP/HTTPS |
| 4 | 3 | Brak nazwy |
| 6 | 5 | Brak ceny |

Raport referencyjny znajduje się w `02_raport-przed.json`.

## 2. Oddziel porządki od naprawy danych

Eksport audytora **usuwa tylko białe znaki na brzegach pól**. W tym przykładzie są to dwie komórki pierwszego produktu: SKU i nazwa. Plik `03_po-samym-trim.csv` pokazuje taki eksport.

Po ponownym wczytaniu pliku 03 nadal zobaczysz **6 problemów**. Narzędzie nie zgaduje cen, nazw, adresów ani poprawnego SKU.

## 3. Porównaj z jawnym źródłem

`04_katalog-zrodlowy-fikcyjny.csv` jest wymyśloną na potrzeby ćwiczenia tabelą referencyjną. Nie jest dowodem o rzeczywistych produktach. Dzięki kolumnie `Pozycja_demo` wiadomo, który produkt odpowiada danemu wierszowi.

Z tej tabeli wynikają dokładnie **5 korekt biznesowych**:

| Pozycja_demo | Pole | Przed | Ze źródła |
|---:|---|---|---|
| 2 | SKU | KUB-01 | TOR-02 |
| 2 | Cena | 1,234 | 39,90 |
| 2 | URL | brak-adresu | https://example.invalid/torba |
| 3 | Nazwa | puste | Notes demonstracyjny |
| 5 | Cena | puste | 34,90 |

`05_po-korektach-ze-zrodla.csv` to wynik tych jawnych korekt oraz dwóch zmian trim. Przygotował go generator pakietu demo na podstawie tabeli 04; **nie jest to automatyczna funkcja naprawy biznesowej publicznego audytora**. Pełny ślad zmian zawiera `ZMIANY_ZE_ZRODLA.json`.

Wczytaj plik 05 do audytora: wynik wyniesie **0 problemów w zakresie obecnych kontroli**. Raport referencyjny to `06_raport-po.json`.

Adresy `example.invalid` celowo nie prowadzą do sklepu. Audytor sprawdza ich składnię, nie dostępność. Puste GTIN nie są obecnie błędem tego audytora — w rzeczywistym feedzie mogą wymagać uzupełnienia lub innego uzgodnienia. Poprawny raport nie oznacza zgodności ze wszystkimi wymaganiami Merchant Center.

## 4. Zamień wynik na uzgodniony zakres pracy

Otwórz [kreator briefu](https://soliddigitalpolska-create.github.io/solid-digital-probki250-13/veyrelo/brief/) i zaimportuj `07_brief-do-importu.json`. Jeżeli masz już wpisane własne dane, najpierw je wyeksportuj; import zastępuje formularz po potwierdzeniu.

Brief zawiera proces, cztery mierzalne kryteria odbioru, ograniczenia i wyłączenia. Oczekiwany stan: **100% kompletności opisu, 1 materiał do dostarczenia** — rzeczywista akceptacja reguł przez właściciela danych. Nie oznacza to otrzymanej zgody klienta. Budżet i termin pozostają puste.

Wersja do przeczytania bez formularza: `08_brief-do-czytania.md`.

## Co dalej przy rzeczywistym zapytaniu

1. Przygotuj małą, pozbawioną danych osobowych próbkę i dokumentację wymaganego importu.
2. Ustal rzeczywiste źródło SKU, nazw, cen i identyfikatorów. Brak źródła oznacza pozycję do wyjaśnienia, nie zgodę na zgadywanie.
3. Dopasuj brief oraz kryteria odbioru. Dopiero po uzgodnieniu zakresu można ustalać wycenę i wdrożenie.

Narzędzia działają lokalnie w przeglądarce. Pakiet nie wysyła danych ani wiadomości i nie wywołuje płatności. Sam raport może zawierać wartości wejściowe — sprawdź go przed udostępnieniem.

## Weryfikacja pakietu

`WERYFIKACJA.json` zawiera rzeczywisty wynik 13 sprawdzeń wykonanych przez istniejące funkcje audytu CSV oraz importu briefu. Nie jest to ponowne uruchomienie pełnego zestawu testów całej platformy. Kod produkcyjny i PM2 nie były zmieniane.
