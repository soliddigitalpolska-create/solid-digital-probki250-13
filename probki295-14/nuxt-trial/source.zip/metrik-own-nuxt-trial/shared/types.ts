export type ProjectStatus = 'plan' | 'active' | 'done'
export interface Project { id:string; title:string; description:string; status:ProjectStatus; progress:number; due:string; color:string }
export interface Workspace { name:string; weeklyDigest:boolean; compactView:boolean }
export interface DemoState { projects:Project[]; workspace:Workspace }
