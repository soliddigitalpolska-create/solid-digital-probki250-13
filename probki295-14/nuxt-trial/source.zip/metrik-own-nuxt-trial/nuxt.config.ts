export default defineNuxtConfig({
  compatibilityDate: '2026-10-14',
  devtools: { enabled: false },
  typescript: { strict: true },
  css: ['~/assets/main.css'],
  app: { head: { title: 'Metrik — własne demo Nuxt 3', htmlAttrs: { lang: 'pl' }, meta: [{ name:'description', content:'Autorski projekt demonstracyjny Nuxt3/Vue3/TypeScript. Fikcyjne dane i lokalne mockAPI.' }] } },
  nitro: { preset: 'node-server' }
})
