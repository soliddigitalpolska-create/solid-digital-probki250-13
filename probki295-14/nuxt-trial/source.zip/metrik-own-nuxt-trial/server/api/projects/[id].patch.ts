import { state } from '../../utils/store'
import type { ProjectStatus } from '../../../shared/types'
export default defineEventHandler(async event=>{
  const project=state.projects.find(p=>p.id===getRouterParam(event,'id'))
  if(!project)throw createError({statusCode:404,statusMessage:'Nie ma takiego projektu'})
  const body=await readBody(event)
  if(!body || typeof body!=='object' || !['plan','active','done'].includes(body.status))throw createError({statusCode:400,statusMessage:'Nieprawidłowy status'})
  project.status=body.status as ProjectStatus
  project.progress=project.status==='done'?100:project.status==='plan'?0:50
  return structuredClone(project)
})
