import { snapshot } from '../utils/store'
export default defineEventHandler(()=>snapshot())
