import { state } from '../utils/store'
export default defineEventHandler(async event=>{
  const body=await readBody(event)
  if(!body || typeof body.name!=='string' || body.name.trim().length<3 || body.name.trim().length>60 || typeof body.weeklyDigest!=='boolean' || typeof body.compactView!=='boolean')throw createError({statusCode:400,statusMessage:'Wymagane: nazwa3–60znaków i ustawienia logiczne'})
  state.workspace={name:body.name.trim(),weeklyDigest:body.weeklyDigest,compactView:body.compactView}
  return structuredClone(state.workspace)
})
