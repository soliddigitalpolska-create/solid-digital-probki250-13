import type { DemoState } from '../../shared/types'
export const state:DemoState={
  workspace:{name:'Pracownia Metrik',weeklyDigest:true,compactView:false},
  projects:[
    {id:'01',title:'Strona pracowni',description:'Projekt i wdrożenie nowej strony',status:'active',progress:68,due:'24 paź',color:'#C1D8BA'},
    {id:'02',title:'System opakowań',description:'Kierunek wizualny i źródła',status:'plan',progress:12,due:'30 paź',color:'#E9C798'},
    {id:'03',title:'Animacja produktu',description:'Storyboard, montaż i napisy',status:'done',progress:100,due:'18 paź',color:'#C8C7E5'}
  ]
}
export const snapshot=()=>structuredClone(state)
