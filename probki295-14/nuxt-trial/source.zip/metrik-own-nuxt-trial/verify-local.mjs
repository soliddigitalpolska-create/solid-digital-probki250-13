import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import crypto from 'node:crypto'
import {fileURLToPath} from 'node:url'
const dir=path.dirname(fileURLToPath(import.meta.url)),base='http://127.0.0.1:8897',tests=[]
async function json(url,init){const r=await fetch(base+url,init);return{status:r.status,data:await r.json()}}
const patch=(data)=>({method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})
const initial=await json('/api/demo');assert.equal(initial.status,200);assert.equal(initial.data.projects.length,3);tests.push({case:'GET_initial_state',status:200,projects:initial.data.projects.length})
const change=await json('/api/projects/01',patch({status:'done'}));assert.equal(change.status,200);assert.equal(change.data.status,'done');assert.equal(change.data.progress,100);tests.push({case:'PATCH_project_done',status:200,project:change.data})
const readback=await json('/api/demo');assert.equal(readback.data.projects.find(p=>p.id==='01').status,'done');tests.push({case:'GET_project_readback',status:200,matched:true})
const badStatus=await json('/api/projects/01',patch({status:'injected'}));assert.equal(badStatus.status,400);tests.push({case:'PATCH_invalid_status_rejected',status:400})
const missing=await json('/api/projects/missing',patch({status:'done'}));assert.equal(missing.status,404);tests.push({case:'PATCH_unknown_id_rejected',status:404})
const badName=await json('/api/workspace',patch({name:'a',weeklyDigest:true,compactView:false}));assert.equal(badName.status,400);tests.push({case:'PATCH_short_name_rejected',status:400})
const ws=await json('/api/workspace',patch({name:'Pracownia próba HTTP',weeklyDigest:false,compactView:true}));assert.equal(ws.status,200);assert.equal(ws.data.compactView,true);tests.push({case:'PATCH_workspace',status:200,workspace:ws.data})
const wsRead=await json('/api/demo');assert.equal(wsRead.data.workspace.name,'Pracownia próba HTTP');tests.push({case:'GET_workspace_readback',status:200,matched:true})
for(const url of ['/','/ustawienia']){const r=await fetch(base+url),text=await r.text();assert.equal(r.status,200);assert.ok(text.includes(url==='/'?'Projekty bez chaosu.':'Pracownia po Twojemu.'));assert.ok(text.includes('Pracownia próba HTTP'));fs.writeFileSync(path.join(dir,url==='/'?'http-projects.html':'http-settings.html'),text);tests.push({case:'SSR_page_'+url,status:200,title_visible:true,current_state_rendered:true})}
await json('/api/projects/01',patch({status:initial.data.projects.find(p=>p.id==='01').status}));await json('/api/workspace',patch(initial.data.workspace));
const sources=['package.json','package-lock.json','nuxt.config.ts','app.vue','pages/index.vue','pages/ustawienia.vue','shared/types.ts','server/api/demo.get.ts','server/api/projects/[id].patch.ts','server/api/workspace.patch.ts','server/utils/store.ts','assets/main.css'];
const hashes=Object.fromEntries(sources.map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,f))).digest('hex')]))
const proof={status:'BUILD_TYPECHECK_HTTP_VERIFIED_BROWSER_QA_PENDING',checked_at:new Date().toISOString(),versions:{nuxt:JSON.parse(fs.readFileSync(path.join(dir,'node_modules/nuxt/package.json'))).version,vue:JSON.parse(fs.readFileSync(path.join(dir,'node_modules/vue/package.json'))).version},typecheck_exit:0,production_build_exit:0,local_base_url:base,tests,source_hashes:hashes,own_fictional_demo:true,commercial_case:false,backend:'Nitro_in_memory_mock_not_Laravel',limitations:['No authentication, database, payments or external messages.','No Laravel/Vuetify/MySQL/Stripe implementation claim.','State is demonstration-only and resets on process restart.','Browserinteraction/visualchecks are root task.']}
fs.writeFileSync(path.join(dir,'proof.json'),JSON.stringify(proof,null,2));console.log(JSON.stringify({tests:tests.length,proof:path.join(dir,'proof.json')}))
